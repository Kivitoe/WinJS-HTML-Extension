// This program shows you how to use if statements in JavaScript.

var x = 9;
var i = 20;
function OnStart(){
if(x < i){// If the arguments in the ()s are true, the code in the {}s are executed. 
	alert('X is less than i!');
	
} else { // If the arguments in the () of the if statement are false, code in the else statement's {}s is executed.
	alert('FAIL!');
}
}