// This program lists different ways to introduce vars (variables) in your program.

//Boolean:
var thisIsABoolean = true;

//Integer:
var thisIsAnInteger = 34;

//String:
var thisIsAString = "Hello!";

//Double:
var thisIsADouble = 34.9;
