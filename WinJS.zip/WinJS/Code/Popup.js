/* This program opens a new window when started. This action is normally blocked by modern browsers unless triggered by user
 * actions.
 */
function OnStart(){ 
window.open( URL, windowName);

// You may also want to push back the window with:
window.focus();
}