// This program alerts the user when opened.
function OnStart(){
alert('You have been alerted!');
}